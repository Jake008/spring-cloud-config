package com.example.swb.aop;

import com.example.swb.entity.Employee;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

import java.lang.reflect.Field;

@Aspect
@Component
public class MyTranscation {

    //@Pointcut("execution(* com.example.swb.service..*.insertInfo(..))")
    @Pointcut("execution(* com.example.swb.service..*.insertInfo(..))")
    public void insertInfo(){
        // boolean flag = transcationTestDao.insertInfo(name);
        // this.insertOnther(name);

    }


    public void beginTransaction(){
        System.out.println("开启事务 ");
    }
    @Around("insertInfo()")
    public void commit(ProceedingJoinPoint joinPoint){
        try {
            Object result = joinPoint.proceed();
            Field name = result.getClass().getField("name");
        } catch (Throwable throwable) {
            throwable.printStackTrace();
        }

        System.out.println("提交事务");
    }

}
