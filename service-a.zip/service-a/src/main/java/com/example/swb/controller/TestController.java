package com.example.swb.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import javax.annotation.Resource;

@RestController
public class TestController {
    @Resource
    private ServiceFeignClient serviceFeignClient;

    @RequestMapping("/call")
    public String call() {
        String result = serviceFeignClient.hello();
        return "调用a的结果是:" + result;
    }

}
