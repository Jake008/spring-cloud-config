package com.example.swb.controller;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;

@FeignClient("SERVICE-OBJCAT-B")
public interface ServiceFeignClient {
    @RequestMapping("/hello")
     String hello();
}
