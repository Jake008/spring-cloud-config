package com.example.swb.service.imp;

import com.example.swb.dao.UserDao;
import com.example.swb.entity.User;
import com.example.swb.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImp implements UserService {

    @Autowired
    private UserDao userDao;

    public User findUserByName(User user ) {
        User user1 =  userDao.findUserByName(user.getUserName());
        return user1;
    }

   public  User findUserByid(String id) {
        User user2 = userDao.findUserByid(id);
        return user2;
   }
}
