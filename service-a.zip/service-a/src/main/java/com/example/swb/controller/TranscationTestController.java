package com.example.swb.controller;

import com.example.swb.entity.Employee;
import com.example.swb.service.TranscationTestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;

@RestController
public class TranscationTestController {

    @Autowired
    private TranscationTestService transcationTestService;

    @GetMapping("/insert")
    public String insertInfo(){
        Employee employee = new Employee();
        employee.setId(UUID.randomUUID().toString());
        employee.setAge("27");
        employee.setName("Jake");
        transcationTestService.insertInfo(employee);
        return "保存成功";
    }

    @GetMapping("/insertOnther")
    public String insertOnther(){
        String result = transcationTestService.insertOnther("Jake");
        return result;

    }


}
