
package com.example.swb.aop;

import com.example.swb.entity.Employee;
import com.example.swb.service.TranscationTestService;
import com.example.swb.service.imp.TranscationTestServiceImp;
import org.junit.Test;

import java.lang.reflect.Proxy;

public class ProxyTest {
    @Test
    public void test() {
        Object target = new TranscationTestServiceImp();
        MyTranscation myTranscation = new MyTranscation();
        PersonServiceInterceptor interceptor = new PersonServiceInterceptor(target, myTranscation);
        TranscationTestService transcationTestService = (TranscationTestService) Proxy.newProxyInstance(target.getClass().getClassLoader(),
                target.getClass().getInterfaces(),interceptor);
       // String returnValue = transcationTestService.insertInfo(new Employee());
        //System.out.println(returnValue);
    }
}

