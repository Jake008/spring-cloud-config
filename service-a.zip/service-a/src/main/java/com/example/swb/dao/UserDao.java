package com.example.swb.dao;

import com.example.swb.entity.User;
import org.springframework.stereotype.Repository;

@Repository
public interface UserDao {
    User findUserByName(String userName);
    User findUserByid(String id);

}
