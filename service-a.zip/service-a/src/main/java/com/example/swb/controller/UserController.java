package com.example.swb.controller;

import com.alibaba.fastjson.JSONObject;
import com.example.swb.entity.User;
import com.example.swb.service.UserService;
import com.example.swb.service.imp.TokenServiceImp;
import com.example.swb.util.TokenUtil;
import com.example.swb.util.UserLoginToken;
import com.fasterxml.jackson.databind.util.JSONPObject;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.oauth2.resource.OAuth2ResourceServerProperties;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

@RestController
public class UserController {

    @Autowired
    private UserService userService;
    @Autowired
    private TokenServiceImp tokenServiceImp;

    /**
     * 用户登录接口
     * @param user
     * @param response
     * @return
     */
    @ApiOperation(value = "登录", notes = "登录")
    @GetMapping("/login")
    public Object login(User user, HttpServletResponse response) {
        JSONObject jsonObject = new JSONObject();
        User userForBase = new User();
        User user1 = userService.findUserByName(user);
        String id = user1.getId();
        userForBase.setId(userService.findUserByName(user).getId());
        userForBase.setUserName(userService.findUserByName(user).getUserName());
        userForBase.setPassword(userService.findUserByName(user).getPassword());
        if (!userForBase.getPassword().equals(user.getPassword())) {
            jsonObject.put("message","登录失败，密码错误");
            return jsonObject;
        } else {
            String token = tokenServiceImp.getToken(userForBase);
            jsonObject.put("token",token);
           // Cookie cookie = new Cookie("token", token);
           // cookie.setPath("/");
          //  response.addCookie(cookie);
            return jsonObject;
        }
    }

    /***
     * 这个请求需要验证token才能访问
     *
     * @author: qiaoyn
     * @date 2019/06/14
     * @return String 返回类型
     */
    @UserLoginToken
    @ApiOperation(value = "获取信息", notes = "获取信息")
    @RequestMapping(value = "/getMessage" ,method = RequestMethod.GET)
    public String getMessage() {
        // 取出token中带的用户id 进行操作
        System.out.println(TokenUtil.getTokenUserId());

        return "您已通过验证";
    }

}
