package com.example.swb.controller;

import java.io.*;

public class FileOperate {
    public static void main(String[] args) {
        File file = new File("d:\\document.txt");
        writeFile("my name is jake", file);
    }

   public void inputStr(){
         InputStreamReader isr = new InputStreamReader(System.in);
        BufferedReader br = new BufferedReader(isr);
        String str = null;
        System.out.println("开始输入");
        try {
            str = br.readLine();
            while (null != str) {
                if(str.equalsIgnoreCase("yes")) {
                    break;
                }
                System.out.println(str.toUpperCase());
                System.out.println("是否停止输入(yes/no)");
                str = br.readLine();
                System.out.println(str);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if(isr != null) {
                try {
                    isr.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if(null != br) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
   }

   public static void writeFile(String str, File file) {
       OutputStream out = null;
       try {
           out = new FileOutputStream(file, true);
           byte [] bytes = str.getBytes();
           out.write(bytes);
           out.flush();
           System.out.println(out.toString());
       } catch (FileNotFoundException e) {
           e.printStackTrace();
       } catch (IOException e) {
           e.printStackTrace();
       }
   }
}
