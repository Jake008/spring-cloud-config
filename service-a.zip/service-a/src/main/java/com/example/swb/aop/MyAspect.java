package com.example.swb.aop;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

/**
 * 切面
 */
@Aspect
@Component("MyTranscation") //切面
public class MyAspect {

    //@Pointcut("excecution(* com.example.swb.service..*(..))")
}
