package com.example.swb.controller;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * 模仿数据库故障，我们前端传入false, 就说明数据库出现客故障
 */
@RestController
public class ProviderController {

    public static Boolean isCanLinkDb = true;

    @RequestMapping(value = "/linkDb/{can}", method = RequestMethod.GET)
    public void LinkDb(@PathVariable Boolean can) {
        isCanLinkDb = can;
    }

    @RequestMapping("/hello01")
    public String hello() {
        return "hello world";
    }
}