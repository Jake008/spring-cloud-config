package com.example.swb.service.imp;

import com.example.swb.dao.TranscationTestDao;
import com.example.swb.entity.Employee;
import com.example.swb.service.TranscationTestService;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;

@Service
public class TranscationTestServiceImp implements TranscationTestService {

    @Autowired
    private TranscationTestDao transcationTestDao;
    @Autowired
    private TranscationTestService transcationTestService;

    @Override
    @Transactional
    public Employee insertInfo(Employee employee){
       // boolean flag = transcationTestDao.insertInfo(name);
       // this.insertOnther(name);
        return employee;
    }
    //@Transactional
    @Override
    public String insertOnther(String name) {
       // boolean flag = transcationTestDao.insertInfo(name);
       // int i = 10/0;

        return "切面测试";
    }
}
