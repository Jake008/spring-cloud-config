/*
package com.example.swb.thread;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class Threadtest {

    public synchronized void method() {
        ReentrantLock reentrantLock = new ReentrantLock();
        reentrantLock.lock();
        ConcurrentHashMap;

        */
/**
         * 唐人神 1.5
         * -- 潍柴动力
         * 徐工机械  2万 +2万
         * 中科曙光 1.5万
         * 目前还有3.5万，  中科曙光：5000，
         *//*

    }
}
*/
