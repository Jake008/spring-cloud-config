package com.example.swb.service;

import com.example.swb.entity.User;

public interface UserService {

    User findUserByName(User user);
    User findUserByid(String id);
}
