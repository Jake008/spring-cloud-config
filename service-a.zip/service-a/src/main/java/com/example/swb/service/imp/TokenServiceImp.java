package com.example.swb.service.imp;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.example.swb.entity.User;
import org.springframework.stereotype.Service;
import java.io.UnsupportedEncodingException;
import java.util.Date;

@Service
public class TokenServiceImp {
    public String getToken(User user) {
        Date start = new Date();
        long currentTime = System.currentTimeMillis() + 60 * 60 * 1000; //一个小时有效
        Date endTime = new Date(currentTime);
        String token = null;
        try {
            token = JWT.create().withAudience(user.getId()).withIssuedAt(start).withExpiresAt(endTime).sign(Algorithm.HMAC256(user.getPassword()));
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return token;
    }
}
