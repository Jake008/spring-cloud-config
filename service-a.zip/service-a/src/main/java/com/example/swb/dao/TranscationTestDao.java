package com.example.swb.dao;

import org.springframework.stereotype.Repository;

import java.util.Date;

@Repository
public interface TranscationTestDao {

    boolean insertInfo(String name);
}
