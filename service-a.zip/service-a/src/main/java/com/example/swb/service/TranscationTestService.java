package com.example.swb.service;

import com.example.swb.entity.Employee;

public interface TranscationTestService {

    Employee insertInfo(Employee employee);

    String insertOnther(String name);
}
