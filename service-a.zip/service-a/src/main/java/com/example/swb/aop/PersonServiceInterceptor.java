
package com.example.swb.aop;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

public class PersonServiceInterceptor implements InvocationHandler {

    //目标类
    private Object target;
    //增强类
    private MyTranscation myTranscation;
    //构造函数注入目标类和增强类
    public PersonServiceInterceptor(Object target, MyTranscation myTranscation) {
        this.target = target;
        this.myTranscation = myTranscation;
    }
    //代理类的每一个方法被调用的时候，都会调用下边这个invoke方法
    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        this.myTranscation.beginTransaction(); //调用自身的方法
        Object returnValue = method.invoke(this.target, args);
      //  this.myTranscation.commit();
        return returnValue;
    }
}

