1：在springboot集成mybatis的时候，遗漏了配置
<dependency>
   <groupId>mysql</groupId>
   <artifactId>mysql-connector-java</artifactId>
</dependency>
导致启动项目报一下错误：
Failed to bind properties under '' to com.zaxxer.hikari.HikariDataSource:
原因：其实就是找不到驱动，而少加的依赖包是加载驱动的。

2:spring 事务
(1)加事务的方法必须是public,否则事务不起作用，另外private 方法, final 方法 和 static 方法不能添加事务，加了也不生效
(2):对于jdbc事务而言，必须是一个connection中才有效的
(3):Spring的事务管理默认只对出现运行期异常(java.lang.RuntimeException及其子类)进行回滚（至于为什么spring要这么设计：因为spring认为Checked的异常属于业务的，
coder需要给出解决方案而不应该直接扔该框架）。如果业务需要，一定要抛出checked异常的话，可以通过rollbackFor属性指定异常类型即可